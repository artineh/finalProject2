import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

public class BaseTest {
    public static WebDriver driver;
    public static String baseUrl ="https://www.sas.am";
    protected HomePage homePage;
    protected SearchResultPage searchResultPage;
    protected ItemPage itemPage;
    List<String> listOfAddresses = Arrays.asList(new String[]{"Մաշտոցի 18","Թումանյան 31","Բաղրամյան 85","Կոմիտաս 52",
    "Իսահակյան 35","Քաջազնունի 20/1","Արշակունյաց 11/1","Կիևյան 1ա"});
    List<String> listOfPhoneNumbers = Arrays.asList(new String[]{"+374 (10) 53-93-99","+374 (10) 53-58-41"
            ,"+374 (10) 22-19-55","+374 (10) 20-83-88",
            "+374 (10) 54-90-54","+374 (10) 55-97-88","","+374 (10) 32-77-88"});


    @BeforeClass
    public void initWebDriver() {
        System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(baseUrl);
        homePage = new HomePage(driver);
    }

    //Test Search Functionality
    @Test
    public void searchSomethingThatDoesNotExist() {
            homePage.enterSearchStr("rehrehheaheherh");
            driver.findElement(By.tagName("h2")).getText().equals("Ոչինչ չի հայտնաբերվել");

        }
        //fails
    @Test
    public void searchSomethingWeKnowExistsWithoutAcceptingOnCookies() {
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        driver.findElement(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div/div/div/a[1]")).click();

    }
    @Test
    public void searchSomethingWeKnowExists() {
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cookies__btn"))).click();
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div/div/div/a[1]"))).click();

    }

    //Test Add/Remove to Favorites functionality
    @Test
    public void addToFav() {
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cookies__btn"))).click();
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div/div/div/a[1]"))).click();
        driver.findElement(By.xpath("///*[@id=\"elem_4222\"]/div[1]/label")).click();
    }
    @Test
    public void removeFav() {
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[4]/div/div/div[3]/div[3]/a"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div/div/div/div[2]/button"))).click();

    }

    //Test Presentations of supermarkets(Address, Phone number )
    @Test
    public void CheckTheSuperMarketValues() {
        driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/div/div[1]/div/ul/li[2]/a")).click();
        List<WebElement> elements = driver.findElements(By.className("shops__point-list"));
        System.out.println(elements.size());
        for (int i = 0; i < elements.size(); i++) {
            System.out.println(elements.get(i).getText().contains(listOfAddresses.get(i)));
            System.out.println(elements.get(i).getText().contains(listOfPhoneNumbers.get(i)));
        }
    }

    //Test Filter Search Results by Country functionality
    //fails
    @Test
    public void ClickingOnCountryName() {
        homePage.enterSearchStr("Հյութ");
        driver.findElement(By.xpath("//span[.='Հայաստան']")).click();
//        String content = driver.findElement(By.className("filter-tags__item-text")).getText() ;
//        System.out.println("Printing " + content);
////        System.out.println("ok");
//
    }

    //passes
    @Test
    public void checkIfCountryNameTagAppears() {
        homePage.enterSearchStr("Հյութ");
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40,1)); //30 represents 30 secs
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[.='Բելգիա']"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("filter-tags__item-text"))).getText().equals("Արտադրման երկիր: Բելգիա");

    }
    @Test
    public void checkIfTheAmountOfProductsAreSmallerThanOrEqual() {
        homePage.enterSearchStr("Հյութ");
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40,1));
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("catalog__col")));
        String numOfProducts = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("js_title_note"))).getText();
        //List<WebElement> products = driver.findElements(By.className("catalog__col"));
        //System.out.println(products.size());
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[.='Բուլղարիա']"))).click();
        String numOfProductsOfCountry = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("js_title_note"))).getText();
        System.out.println(numOfProducts);
        System.out.println(numOfProductsOfCountry);
        //List<WebElement> productsOfBulgaria = driver.findElements(By.className("product__cover-link"));
        //System.out.println(productsOfBulgaria.size());




    }
    @AfterClass
    public static void tearDown() {
        driver.quit();
    }
}

