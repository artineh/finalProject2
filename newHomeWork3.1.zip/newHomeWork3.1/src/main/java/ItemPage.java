import org.openqa.selenium.WebDriver;

public class ItemPage {
    WebDriver driver;

    public ItemPage(WebDriver driver) {
        this.driver = driver;
    }

}
