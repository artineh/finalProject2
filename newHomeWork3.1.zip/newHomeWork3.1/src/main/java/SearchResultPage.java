import org.openqa.selenium.WebDriver;
//import static Constants.Locators.Locators.webElements;

public class SearchResultPage {
    WebDriver driver;

    public SearchResultPage(WebDriver driver) {
        this.driver = driver;
    }
    public void searchResult(){
        //driver.findElements();
    }
//    public String SearchResultHeader(){
//        return driver.findElement(By.xpath(searchResultHeader));
//    }
}

