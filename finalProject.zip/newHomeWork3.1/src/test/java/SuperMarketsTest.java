import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.List;

public class SuperMarketsTest  extends BaseTest{
    //Test Presentations of supermarkets(Address, Phone number )
    @Test
    public void CheckTheSuperMarketValues() {
        driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/div/div[1]/div/ul/li[2]/a")).click();
        List<WebElement> elements = driver.findElements(By.className("shops__point-list"));
        System.out.println(elements.size());
        for (int i = 0; i < elements.size(); i++) {
            System.out.println(elements.get(i).getText().contains(listOfAddresses.get(i)));
            System.out.println(elements.get(i).getText().contains(listOfPhoneNumbers.get(i)));
        }
    }

}
