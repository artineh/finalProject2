import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class FavoritesTest extends BaseTest {
    //Test Add/Remove to Favorites functionality
    @Test
    public void addToFav() {
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cookies__btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("card__favorites-btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("page-header__link-counter"))).getText().equals("1");

    }
    @Test
    public void addThenRemoveFav() {
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cookies__btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("card__favorites-btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("page-header__link-counter"))).getText().equals("1");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("card__favorites-btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("page-header__link-counter"))).getText().equals("0");

    }

}
