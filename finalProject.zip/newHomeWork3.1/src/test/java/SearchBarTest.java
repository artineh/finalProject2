import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class SearchBarTest extends BaseTest {
    //Test Search Functionality
    //passes
    @Test
    public void searchSomethingThatDoesNotExist() {
        homePage.enterSearchStr("rehrehheaheherh");
        driver.findElement(By.tagName("h2")).getText().equals("Ոչինչ չի հայտնաբերվել");

    }
    //fails as the cookies message does not let the product to be clickable
    @Test
    public void searchSomethingWeKnowExistsWithoutAcceptingOnCookies() {
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        driver.findElement(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div/div/div/a[1]")).click();

    }
    //passes
    @Test
    public void searchSomethingWeKnowExists() {
        homePage.enterSearchStr("Հյութ «Granini» 0.25լ Արքայախնձոր");
        WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(30,1));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cookies__btn"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ajaxreloadcatalog\"]/div[1]/div"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("card__title"))).getText().equals("Հյութ «Granini» 0.25լ Արքայախնձոր");

    }

}
