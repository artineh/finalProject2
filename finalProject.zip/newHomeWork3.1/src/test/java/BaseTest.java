import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

public class BaseTest {
    public static WebDriver driver;
    public static String baseUrl ="https://www.sas.am";
    protected HomePage homePage;
    protected SearchResultPage searchResultPage;
    protected ItemPage itemPage;
    List<String> listOfAddresses = Arrays.asList(new String[]{"Մաշտոցի 18","Թումանյան 31","Բաղրամյան 85","Կոմիտաս 52",
    "Իսահակյան 35","Քաջազնունի 20/1","Արշակունյաց 11/1","Կիևյան 1ա","Հալաբյան 22/5"});
    List<String> listOfPhoneNumbers = Arrays.asList(new String[]{"+374 (10) 53-93-99","+374 (10) 53-58-41"
            ,"+374 (10) 22-19-55","+374 (10) 20-83-88",
            "+374 (10) 54-90-54","+374 (10) 55-97-88","","+374 (10) 32-77-88",""});


    @BeforeClass
    public void initWebDriver() {
        System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(baseUrl);
        homePage = new HomePage(driver);
    }
    @AfterMethod //AfterMethod annotation - This method executes after every test execution
    public void recordFailure(ITestResult result){
//using ITestResult.FAILURE is equals to result.getStatus then it enter into if condition

        if(ITestResult.FAILURE==result.getStatus()){
            var camera = (TakesScreenshot)driver;
            File screenshot= camera.getScreenshotAs(OutputType.FILE);
            try{
                Files.move(screenshot, new File("resources/screenshots/"+ result.getName()+".png"));
                System.out.println("Successfully captured a screenshot");
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }


    @AfterClass
    public static void tearDown() {
        driver.quit();
    }
}

