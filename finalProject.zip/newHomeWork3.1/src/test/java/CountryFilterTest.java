import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class CountryFilterTest extends BaseTest {
    //Test Filter Search Results by Country functionality
    //fails as the cookie message blocks that item
    @Test
    public void ClickingOnCountryName() {
        homePage.enterSearchStr("Հյութ");
        driver.findElement(By.xpath("//span[.='Հայաստան']")).click();
//        String content = driver.findElement(By.className("filter-tags__item-text")).getText() ;
//        System.out.println("Printing " + content);
////        System.out.println("ok");
//
    }
    //passes
    @Test
    public void checkIfCountryNameTagAppears() {
        homePage.enterSearchStr("Հյութ");
        WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40,1)); //30 represents 30 secs
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[.='Բելգիա']"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("filter-tags__item-text"))).getText().equals("Արտադրման երկիր: Բելգիա");

    }
    //passes
    @Test
    public void checkIfTheAmountOfProductsAreSmallerThanOrEqual() {
        homePage.enterSearchStr("Հյութ");
        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40,1));
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("catalog__col")));
        String numOfProducts = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("js_title_note"))).getText();
        //List<WebElement> products = driver.findElements(By.className("catalog__col"));
        //System.out.println(products.size());
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[.='Բուլղարիա']"))).click();
        String numOfProductsOfCountry = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("js_title_note"))).getText();
        System.out.println(numOfProducts);
        System.out.println(numOfProductsOfCountry);
        //List<WebElement> productsOfBulgaria = driver.findElements(By.className("product__cover-link"));
        //System.out.println(productsOfBulgaria.size());




    }
}
