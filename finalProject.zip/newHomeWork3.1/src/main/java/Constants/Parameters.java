package Constants;

public class Parameters {

}
